# Homework header as usual
#
#
#

class Gene:
	"""
	# class body with documentation
	# initialise the class, and define methods to calculate GC content, add 2 sequences, and find the complement of a strand
	"""